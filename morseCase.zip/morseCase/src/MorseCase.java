import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.Normalizer;
import java.util.HashMap;
import java.util.Map;

public class MorseCase {
    private static final Map<String, String> morseToCharMap = new HashMap<>();

    static {
        // Initialise la table de correspondance entre le morse et les caractères
        morseToCharMap.put(".-", "A");
        morseToCharMap.put("-...", "B");
        morseToCharMap.put("-.-.", "C");
        morseToCharMap.put("-..", "D");
        morseToCharMap.put(".", "E");
        morseToCharMap.put("..-.", "F");
        morseToCharMap.put("--.", "G");
        morseToCharMap.put("....", "H");
        morseToCharMap.put("..", "I");
        morseToCharMap.put(".---", "J");
        morseToCharMap.put("-.-", "K");
        morseToCharMap.put(".-..", "L");
        morseToCharMap.put("--", "M");
        morseToCharMap.put("-.", "N");
        morseToCharMap.put("---", "O");
        morseToCharMap.put(".--.", "P");
        morseToCharMap.put("--.-", "Q");
        morseToCharMap.put(".-.", "R");
        morseToCharMap.put("...", "S");
        morseToCharMap.put("-", "T");
        morseToCharMap.put("..-", "U");
        morseToCharMap.put("...-", "V");
        morseToCharMap.put(".--", "W");
        morseToCharMap.put("-..-", "X");
        morseToCharMap.put("-.--", "Y");
        morseToCharMap.put("--..", "Z");
        morseToCharMap.put(".----", "1");
        morseToCharMap.put("..---", "2");
        morseToCharMap.put("...--", "3");
        morseToCharMap.put("....-", "4");
        morseToCharMap.put(".....", "5");
        morseToCharMap.put("-....", "6");
        morseToCharMap.put("--...", "7");
        morseToCharMap.put("---..", "8");
        morseToCharMap.put("----.", "9");
        morseToCharMap.put("-----", "0");
        morseToCharMap.put("/", " ");
    }

    private static final Map<String, String> specialCharMap = new HashMap<>();

    static {
        // Initialise la table de correspondance entre les caractères spéciaux et leur équivalent en français
        specialCharMap.put("C3A7", "ç");
        specialCharMap.put("C3A9", "é");
        specialCharMap.put("C3A0", "à");
        specialCharMap.put("C3A8", "è");
    }

    public static void main(String[] args) {
        String inputFile = "../morseCase/inputText.txt";
        String outputFile = "../morseCase/outputText.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String translatedText = translateMorseToText(line);
                writer.write(line);
                writer.newLine();
                writer.write(translatedText);
                writer.newLine();
            }
            System.out.println("Traduction terminée. Le résultat a été enregistré dans " + outputFile);
        } catch (IOException e) {
            System.err.println("Erreur lors de la lecture ou de l'écriture du fichier : " + e.getMessage());
        }
    }

    private static String translateMorseToText(String morse) {
        StringBuilder result = new StringBuilder();
        String[] words = morse.split(" / ");

        for (String word : words) {
            String[] characters = word.split(" ");
            for (String character : characters) {
                if (morseToCharMap.containsKey(character)) {
                    String translatedChar = morseToCharMap.get(character);
                    translatedChar = normalizeSpecialCharacters(translatedChar);
                    result.append(translatedChar);
                } else {
                    result.append(" ");
                }
            }
            result.append("?");
        }

        return result.toString().trim();
    }

    private static String normalizeSpecialCharacters(String text) {
        String normalizedText = Normalizer.normalize(text, Normalizer.Form.NFD);
        normalizedText = normalizedText.replaceAll("[^\\p{ASCII}]", "");

        // Vérifie si le caractère spécial est présent dans la table de correspondance
        if (specialCharMap.containsKey(normalizedText)) {
            normalizedText = specialCharMap.get(normalizedText);
        }

        return normalizedText;
    }
}
